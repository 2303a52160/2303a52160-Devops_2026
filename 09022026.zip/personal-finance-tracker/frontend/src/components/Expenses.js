import React, { useState, useEffect } from 'react';
import './Expenses.css';

// ❌ REMOVE THESE - No longer needed
// import axios from 'axios';
// const API_URL = 'http://localhost:5000/api/expenses';

const Expenses = () => {
  const [expenses, setExpenses] = useState([]);
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    title: '',
    amount: '',
    category: 'Food',
    date: '',
    description: ''
  });
  const [errors, setErrors] = useState({});

  // Load expenses when component mounts
  useEffect(() => {
    fetchExpenses();
  }, []);

  // ✅ LOAD from localStorage
  const fetchExpenses = () => {
    try {
      setLoading(true);
      const storedExpenses = localStorage.getItem('expenses');
      if (storedExpenses) {
        setExpenses(JSON.parse(storedExpenses));
      } else {
        setExpenses([]);
      }
      setLoading(false);
    } catch (error) {
      console.error('Error loading expenses:', error);
      alert('Error loading expenses');
      setLoading(false);
    }
  };

  // Validate form
  const validateForm = () => {
    const newErrors = {};

    if (!formData.title.trim()) {
      newErrors.title = 'Title is required';
    }

    if (!formData.amount || formData.amount <= 0) {
      newErrors.amount = 'Amount must be greater than 0';
    }

    if (!formData.category) {
      newErrors.category = 'Category is required';
    }

    if (!formData.date) {
      newErrors.date = 'Date is required';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  // Handle input changes
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value
    });
    
    // Clear error when user types
    if (errors[name]) {
      setErrors({
        ...errors,
        [name]: ''
      });
    }
  };

  // Show message helper
  const showMessage = (message, type) => {
    if (type === 'success') {
      alert('✅ ' + message);
    } else {
      alert('❌ ' + message);
    }
  };

  // ✅ SAVE to localStorage
  const handleSubmit = (e) => {
    e.preventDefault();

    if (!validateForm()) {
      showMessage('Please fix the errors in the form', 'error');
      return;
    }

    try {
      // Create new expense
      const newExpense = {
        id: Date.now().toString(),
        title: formData.title.trim(),
        amount: parseFloat(formData.amount),
        category: formData.category,
        date: formData.date,
        description: formData.description.trim(),
        createdAt: new Date().toISOString()
      };

      // Get existing expenses
      const storedExpenses = localStorage.getItem('expenses');
      const existingExpenses = storedExpenses ? JSON.parse(storedExpenses) : [];

      // Add new expense
      const updatedExpenses = [...existingExpenses, newExpense];

      // Save to localStorage
      localStorage.setItem('expenses', JSON.stringify(updatedExpenses));

      // Update state
      setExpenses(updatedExpenses);

      // Success message
      showMessage('Expense added successfully!', 'success');

      // Reset form
      setFormData({
        title: '',
        amount: '',
        category: 'Food',
        date: '',
        description: ''
      });

      setErrors({});

    } catch (error) {
      console.error('Error adding expense:', error);
      showMessage('Error adding expense. Please try again.', 'error');
    }
  };

  // ✅ DELETE from localStorage
  const deleteExpense = (id) => {
    if (window.confirm('Are you sure you want to delete this expense?')) {
      try {
        const updatedExpenses = expenses.filter(exp => exp.id !== id);
        localStorage.setItem('expenses', JSON.stringify(updatedExpenses));
        setExpenses(updatedExpenses);
        showMessage('Expense deleted successfully!', 'success');
      } catch (error) {
        console.error('Error deleting expense:', error);
        showMessage('Error deleting expense', 'error');
      }
    }
  };

  // Calculate total
  const totalAmount = expenses.reduce((sum, exp) => sum + exp.amount, 0);

  return (
    <div className="expense-container">
      <div className="header">
        <h1>💰 Expense Tracker</h1>
      </div>

      <div className="main-content">
        {/* Add Expense Form */}
        <div className="form-section">
          <h2>Add New Expense</h2>
          <form onSubmit={handleSubmit}>
            
            <div className="form-group">
              <label>Title *</label>
              <input
                type="text"
                name="title"
                value={formData.title}
                onChange={handleInputChange}
                placeholder="Grocery"
                className={errors.title ? 'error' : ''}
              />
              {errors.title && <span className="error-text">{errors.title}</span>}
            </div>

            <div className="form-row">
              <div className="form-group">
                <label>Amount (₹) *</label>
                <input
                  type="number"
                  name="amount"
                  value={formData.amount}
                  onChange={handleInputChange}
                  placeholder="15000"
                  min="0"
                  step="0.01"
                  className={errors.amount ? 'error' : ''}
                />
                {errors.amount && <span className="error-text">{errors.amount}</span>}
              </div>

              <div className="form-group">
                <label>Category *</label>
                <select
                  name="category"
                  value={formData.category}
                  onChange={handleInputChange}
                  className={errors.category ? 'error' : ''}
                >
                  <option value="Food">Food</option>
                  <option value="Transport">Transport</option>
                  <option value="Entertainment">Entertainment</option>
                  <option value="Shopping">Shopping</option>
                  <option value="Bills">Bills</option>
                  <option value="Health">Health</option>
                  <option value="Education">Education</option>
                  <option value="Others">Others</option>
                </select>
                {errors.category && <span className="error-text">{errors.category}</span>}
              </div>
            </div>

            <div className="form-group">
              <label>Date *</label>
              <input
                type="date"
                name="date"
                value={formData.date}
                onChange={handleInputChange}
                className={errors.date ? 'error' : ''}
              />
              {errors.date && <span className="error-text">{errors.date}</span>}
            </div>

            <div className="form-group">
              <label>Description</label>
              <textarea
                name="description"
                value={formData.description}
                onChange={handleInputChange}
                placeholder="Optional notes..."
                rows="3"
              />
            </div>

            <button type="submit" className="btn-submit" disabled={loading}>
              {loading ? 'Adding...' : 'Add Expense'}
            </button>
          </form>
        </div>

        {/* Expenses List */}
        <div className="expenses-section">
          <div className="total-section">
            <h3>Total Expenses</h3>
            <p className="total-amount">₹{totalAmount.toFixed(2)}</p>
            <p className="expense-count">{expenses.length} expense{expenses.length !== 1 ? 's' : ''}</p>
          </div>

          <div className="expenses-list">
            <h2>Recent Expenses</h2>
            
            {loading ? (
              <p>Loading...</p>
            ) : expenses.length === 0 ? (
              <p className="no-data">No expenses yet. Add your first expense above! 📝</p>
            ) : (
              <div className="expense-items">
                {expenses.map((expense) => (
                  <div key={expense.id} className="expense-card">
                    <div className="expense-header">
                      <h3>{expense.title}</h3>
                      <span className={`category-badge ${expense.category.toLowerCase()}`}>
                        {expense.category}
                      </span>
                    </div>
                    
                    <div className="expense-details">
                      <p className="expense-amount">₹{expense.amount.toFixed(2)}</p>
                      <p className="expense-date">📅 {expense.date}</p>
                      {expense.description && (
                        <p className="expense-description">{expense.description}</p>
                      )}
                    </div>
                    
                    <button 
                      onClick={() => deleteExpense(expense.id)}
                      className="btn-delete"
                    >
                      🗑️ Delete
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Expenses;